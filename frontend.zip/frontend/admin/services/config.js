const config = {
        domain: 'http://localhost:3000',
        apiVersion: 'v1',
        endpoints: {
                adminPage: '/admin',
                adminPages: 'admin/pages',
                sidebarList: '/admin/sidebar',
                
        }
}

export default config;  