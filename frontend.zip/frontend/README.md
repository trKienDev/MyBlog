Sử dụng http-server để quản lý trình duyệt.
Nếu muốn vô hiệu hoá cache: mở Developer Tools --> Network --> Disable cachce
