function handleDOMContentLoaded() {
        var title = document.querySelector('title');
        var path = window.location.pathname;
        if (path.includes('index')) {
                title.innerText = 'Homepage';
        } else if (path.includes('about')) {
                title.innerText = 'About Us';
        } else if (path.includes('post')) {
                title.innerText = 'Blog Post';
        } else {
                title.innerText = 'My Website';
        }
}

// Thêm cơ chế đợi khi toàn bộ document được loading xong thì mới thực hiện DOMContentLoaded.
if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", handleDOMContentLoaded);
} else {
        handleDOMContentLoaded();
}