const config = {
        domain: 'http://localhost:3000',
        apiVersion: 'v1',
        endpoints: {
                homePage: '/',
        }
}

export default config;  